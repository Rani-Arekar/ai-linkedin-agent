from pydantic import BaseModel

from config import get_settings
from services.llm_service import GeminiProvider


class TestResponse(BaseModel):
    answer: str


settings = get_settings()
provider = GeminiProvider(settings)

print("Model:", provider._model)
print("Testing Gemini...")

result = provider.generate(
    "Return exactly GEMINI_TEST_OK in the answer field.",
    TestResponse,
)

print("Result:", result.answer)